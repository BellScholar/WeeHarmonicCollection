document.addEventListener("DOMContentLoaded", function () {
    // Sample data for songs
    const songs = [
        {
            title: "Song 1 Title",
            artist: "Artist 1",
            audioSrc: "song1.mp3",
            coverSrc: "song1.jpg",
        },
        {
            title: "Song 2 Title",
            artist: "Artist 2",
            audioSrc: "song2.mp3",
            coverSrc: "song2.jpg",
        },
        // Add more songs as needed
    ];

    // Function to create and add song items to the song list
    function createSongItem(song) {
        const songList = document.getElementById("song-list");
        const li = document.createElement("li");
        li.innerHTML = `
            <img src="${song.coverSrc}" alt="${song.title} Cover">
            <h3>${song.title}</h3>
            <p>${song.artist}</p>
            <audio controls>
                <source src="${song.audioSrc}" type="audio/mpeg">
                Your browser does not support the audio element.
            </audio>
        `;
        songList.appendChild(li);
    }

    // Populate the song list
    songs.forEach(createSongItem);
});