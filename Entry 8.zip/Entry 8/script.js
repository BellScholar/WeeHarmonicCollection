// Your JavaScript code can go here
document.addEventListener("DOMContentLoaded", function () {
    const flippableImages = document.querySelectorAll(".flippable-image");

    flippableImages.forEach((image) => {
        image.addEventListener("click", function () {
            image.classList.toggle("flip");
        });
    });
});
